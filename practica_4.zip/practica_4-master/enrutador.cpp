#include "enrutador.h"

enrutador::enrutador(string _nombre)
{
    nombre = _nombre;
    sig = NULL;
    ari = NULL;
}


enrutador::~enrutador()
{

}
